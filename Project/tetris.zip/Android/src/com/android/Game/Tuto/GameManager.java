package com.android.Game.Tuto;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.Entity;
import org.anddev.andengine.entity.primitive.Rectangle;
import org.anddev.andengine.entity.scene.background.ColorBackground;

import java.util.Random;
import com.android.Game.Tuto.spiriteModel;
public class GameManager {
	
	public Scene myscene;
	public Random randomGenerator;
	public Random randomGeneratorColor;
	public spiriteModel [][] mymodel;
	
	public  spiriteModel [][] typemodel0;
	public  spiriteModel [][] typemodel1;
	public  spiriteModel [][] typemodel2;
	public  spiriteModel [][] typemodel3;
	public  spiriteModel [][] typemodel4;
	public  spiriteModel [][] typemodel5;
	public  spiriteModel [][] typemodel6;
	///***************************next generation
	public  spiriteModel [][] typemodel7;
	public  spiriteModel [][] typemodel8;
	public  spiriteModel [][] typemodel9;
	public  spiriteModel [][] typemodel10;
	public  spiriteModel [][] typemodel11;
	public  spiriteModel [][] typemodel12;
	public  spiriteModel [][] typemodel13;
	
	
	///********************************************
	public  spiriteModel [][] current_typemodel;
	public  spiriteModel [][] next_typemodel;
	
	public  spiriteModel [][] temp_current_typemodel;
	
	public int current_ship;
	public int current_state;
	public int centerPosX;
	public int centerPosY;
	public boolean first_time;
	public int cocolor;
	public boolean no_chip;
	public long last_down;
	public boolean calculate_is_performed;
	public int score;
	public int lines;
	public int best_lines;
	public int next,current;
	boolean extrat_mode;
	public GameManager(Scene _scene)
	
	{   extrat_mode=false;
		next=current;
		best_lines=0;
		lines=0;
		calculate_is_performed=false;
		score=0;
		last_down=System.currentTimeMillis();
		first_time=true;
		no_chip=true;
		myscene=_scene;	
		randomGenerator = new Random(System.currentTimeMillis());next=current=randomGenerator.nextInt(7);
		randomGeneratorColor = new Random(System.currentTimeMillis());cocolor = randomGeneratorColor.nextInt(10);
		
		mymodel=new spiriteModel[22][12];
		typemodel0=new spiriteModel[5][5];
		typemodel1=new spiriteModel[5][5];
		typemodel2=new spiriteModel[5][5];
		typemodel3=new spiriteModel[5][5];
		typemodel4=new spiriteModel[5][5];
		typemodel5=new spiriteModel[5][5];
		typemodel6=new spiriteModel[5][5];
		//*****extra piece*
		typemodel7=new spiriteModel[5][5];
		typemodel8=new spiriteModel[5][5];
		typemodel9=new spiriteModel[5][5];
		typemodel10=new spiriteModel[5][5];
		typemodel11=new spiriteModel[5][5];
		typemodel12=new spiriteModel[5][5];
		typemodel13=new spiriteModel[5][5];
		
		
		
		//******
	    next_typemodel=new spiriteModel[5][5];
		current_typemodel=new spiriteModel[5][5];
		temp_current_typemodel= new spiriteModel[5][5];
		
	//	current_ship = randomGenerator.nextInt(3);
		//**********initialise the global game table to void
		for(int i=0;i<22;i++)
			for( int j=0;j<12;j++)
				{ 
				mymodel[i][j]= new spiriteModel();
				mymodel[i][j].filled=false;
				mymodel[i][j].rect=new Rectangle(0, 0, 21, 21);	
				
				
				
				}
		
				
		
	//	if(1==1) return;
		
		//**********initialise all ship to void
		int x_next,y_next;
		x_next=8;
		y_next=15;
		for(int i=0;i<5;i++)
			for( int j=0;j<5;j++)
			{   
				typemodel0[i][j]=new spiriteModel();
				typemodel1[i][j]=new spiriteModel();
				typemodel2[i][j]=new spiriteModel();
				typemodel3[i][j]=new spiriteModel();
				typemodel4[i][j]=new spiriteModel();
				typemodel5[i][j]=new spiriteModel();
				typemodel6[i][j]=new spiriteModel();
				//***
				typemodel7[i][j]=new spiriteModel();
				typemodel8[i][j]=new spiriteModel();
				typemodel9[i][j]=new spiriteModel();
				typemodel10[i][j]=new spiriteModel();
				typemodel11[i][j]=new spiriteModel();
				typemodel12[i][j]=new spiriteModel();
				typemodel13[i][j]=new spiriteModel();
				//***
				
				
				
				
				temp_current_typemodel[i][j]=new spiriteModel();
				next_typemodel[i][j]=new spiriteModel();
				next_typemodel[i][j].rect=new Rectangle(0, 0, 30, 30);
				current_typemodel[i][j]=new spiriteModel();
				current_typemodel[i][j].rect=new Rectangle(0, 0, 21, 21);
				
				temp_current_typemodel[i][j].filled=false;
				current_typemodel[i][j].filled=false;
				next_typemodel[i][j].filled=false;next_typemodel[i][j].rect.setPosition((j+y_next)*31, (i+x_next)*31);
				typemodel0[i][j].filled=false;	
				typemodel1[i][j].filled=false;
				typemodel2[i][j].filled=false;
				typemodel3[i][j].filled=false;
				typemodel4[i][j].filled=false;
				typemodel5[i][j].filled=false;
				typemodel6[i][j].filled=false;
				//**
				typemodel7[i][j].filled=false;
				typemodel8[i][j].filled=false;
				typemodel9[i][j].filled=false;
				typemodel10[i][j].filled=false;
				typemodel11[i][j].filled=false;
				typemodel12[i][j].filled=false;
				typemodel13[i][j].filled=false;
				//**
			}
		//fill the first ship	
		typemodel1[0][2].filled=true;typemodel1[1][2].filled=true;
		typemodel1[2][2].filled=true;typemodel1[3][2].filled=true;
		//fill the second ship	
	//*****************	
		typemodel2[2][2].filled=true;typemodel2[2][1].filled=true;
		typemodel2[2][3].filled=true;typemodel2[1][3].filled=true;
		
		
		//fill the third ship
		typemodel0[2][2].filled=true;typemodel0[2][1].filled=true;
		typemodel0[2][3].filled=true;typemodel0[1][1].filled=true;
		// fill ship number 4
		typemodel3[2][2].filled=true;typemodel3[2][1].filled=true;
		typemodel3[2][3].filled=true;typemodel3[1][2].filled=true;
		
		
	//**************************************************	
		
		//fill ship number 5
		typemodel4[1][2].filled=true;typemodel4[1][3].filled=true;
		typemodel4[2][2].filled=true;typemodel4[2][3].filled=true;
		
		typemodel5[2][2].filled=true;typemodel5[2][3].filled=true;
		typemodel5[3][2].filled=true;typemodel5[1][3].filled=true;
		
		typemodel6[2][2].filled=true;typemodel6[3][2].filled=true;
		typemodel6[2][1].filled=true;typemodel6[1][1].filled=true;
		//**************fill extra ship
		typemodel7[2][2].filled=true;//the point ship
		
		typemodel8[2][2].filled=true;
		typemodel8[1][2].filled=true;
		typemodel8[3][2].filled=true;
		
		typemodel9[2][2].filled=true;
		typemodel9[1][2].filled=true;
		typemodel9[1][3].filled=true;
		
		typemodel10[2][2].filled=true;
		typemodel10[1][2].filled=true;
		typemodel10[2][3].filled=true;
		
		typemodel11[2][2].filled=true;
		typemodel11[1][2].filled=true;
		
		
		
		for(int ii=1;ii<4;ii++)
			for(int jj=1;jj<4;jj++)
				typemodel12[ii][jj].filled=true;
		
		
		for(int ii=0;ii<5;ii++)
			for(int jj=0;jj<5;jj++)
				typemodel13[ii][jj].filled=true;
		//****************************************
		
		
		
		
	
	// create the left and right and down wall
		int r,g,b;
		r=80;
		g=128;
		b=80;
	for(int j=0;j<12;j++)
		{mymodel[21][j].filled=true;mymodel[21][j].r=r;mymodel[21][j].g=g;mymodel[21][j].b=b;
		//mymodel[21][j].rect=new Rectangle(0, 0, 21, 21);
		}
	for( int i=0;i<22;i++)	
		{mymodel[i][0].filled=true;mymodel[i][0].r=r;mymodel[i][0].g=g;mymodel[i][0].b=b;
	//	mymodel[i][0].rect=new Rectangle(0, 0, 21, 21);
		}
	for( int i=0;i<22;i++)	
		{mymodel[i][11].filled=true;mymodel[i][11].r=r;mymodel[i][11].g=g;mymodel[i][11].b=b;
		//mymodel[i][11].rect=new Rectangle(0, 0, 21, 21);
		}
	}// my init function
	

	public	boolean downShip()
			{
				
		// this code is applicable for each chips, for this we test all the matrices [5][5]   
		
		//check all column and find the
		
		boolean find;
		
		int last_find=0;
		boolean can_down=true;
		for(int j=0;j<5;j++)
		{
		find=false;
		for(int i=0;i<5;i++)
		{
		if(current_typemodel[i][j].filled==true){find=true;last_find=i;}	
		}
		if(find==true)
						  // checke the point just under our find
						if(mymodel[last_find+centerPosX+1][centerPosY+j].filled==true)
																	{
																	can_down=false; break;
																	}
						
						
		}// for j
		
		
		if(can_down)centerPosX++; else score+=10;
		    return can_down;// you down the object or not
	        }
	
	
	public	boolean move_to_right_Ship()
	{
		
// this code is applicable for each chips, for this we test all the matrices [5][5]   

//check all column and find the

boolean find;

int last_find=0;
boolean can_move_to_right=true;
for(int i=0;i<5;i++)
{
find=false;
for(int j=0;j<5;j++)
{
if(current_typemodel[i][j].filled==true){find=true;last_find=j;}	
}
if(find==true)
				  // checke the point just under our find
				if(mymodel[centerPosX+i][centerPosY+last_find+1].filled==true)
															{
															can_move_to_right=false; break;
															}
				
				
}// for j


   if(can_move_to_right)centerPosY++;
    return can_move_to_right;// you down the object or not
    }

public	boolean move_to_left_Ship()
{

//this code is applicable for each chips, for this we test all the matrices [5][5]   

//check all column and find the

boolean find;

int last_find=0;
boolean can_move_to_left=true;
for(int i=0;i<5;i++)
{
find=false;
for(int j=4;j>=0;j--)
{
if(current_typemodel[i][j].filled==true){find=true;last_find=j;}	
}
if(find==true)
		  // checke the point just under our find
		if(mymodel[centerPosX+i][centerPosY+last_find-1].filled==true)
													{
													can_move_to_left=false; break;
													}
		
		
}// for j


if(can_move_to_left)centerPosY--;
return can_move_to_left;// you down the object or not
}


	private void copy_to_current_model(int index) {
		// TODO Auto-generated method stub
		
	}

	
	//****************************************************************************
	/*
	 * Color(250,120,0);
	 * 
	 */
	 
	//****************************************************************************
	public void paint_scene()
	{
	/*	myscene.setBackground(new ColorBackground(0, 0, 0));*/
		myscene.setBackground(new ColorBackground(0, 0, 0));
	//	Rectangle rectangle;
		
		if(first_time==true)
		{
			first_time=false;
			
			for(int i=0;i<22;i++)
				for(int j=0;j<12;j++)
					myscene.attachChild(mymodel[i][j].rect);
			for(int i=0;i<5;i++)
		    	for(int j=0;j<5;j++)
		    		myscene.attachChild(current_typemodel[i][j].rect);
				
			for(int i=0;i<5;i++)
		    	for(int j=0;j<5;j++)
		    		myscene.attachChild(next_typemodel[i][j].rect);
		}
		
		  for(int i=0;i<5;i++)
		    	for(int j=0;j<5;j++)
		    		if(current_typemodel[i][j].filled==true) 
		    	{
		    			current_typemodel[i][j].rect.setPosition((j+centerPosY)*22, (i+centerPosX)*22);
		    			myscene.getChild(myscene.getChildIndex(current_typemodel[i][j].rect)).setVisible(true);
		    			 }
		    		else {	
	    			myscene.getChild(myscene.getChildIndex(current_typemodel[i][j].rect)).setVisible(false);   
		    		} 
		  for(int i=0;i<5;i++)
		    	for(int j=0;j<5;j++)
		    		if(next_typemodel[i][j].filled==true) 
		    	{
		    	myscene.getChild(myscene.getChildIndex(next_typemodel[i][j].rect)).setVisible(true);
		    	}
		    		else {
		    			myscene.getChild(myscene.getChildIndex(next_typemodel[i][j].rect)).setVisible(false);    
		    		}
		
		
	    for(int i=0;i<22;i++)
	    	for(int j=0;j<12;j++)
	    		if(mymodel[i][j].filled==true) 
	    		{
	    			
	    			//rectangle =new Rectangle(j*22,i*22, 21, 21);
	    			mymodel[i][j].rect.setPosition(j*22, i*22);
	    			//mymodel[i][j].rect.setColor(mymodel[i][j].r,mymodel[i][j].g,mymodel[i][j].b);
	    			myscene.getChild(myscene.getChildIndex(mymodel[i][j].rect)).setVisible(true);/**/
	    			
	    			
	    			//rectangle=null;
	    		}
	    		else {	/*mymodel[i][j].rect.setPosition(j*22, i*22);
    			mymodel[i][j].rect.setColor(0,0,0);*/
    			myscene.getChild(myscene.getChildIndex(mymodel[i][j].rect)).setVisible(false);
    			//myscene.detachChild(mymodel[i][j].rect);	
	    		}
	    
	    
	}
//*********************************************************************************
	
public void generate_new_ship()
{   
	no_chip=false;// we have now one ship
	current=next;
	if(this.extrat_mode==true)  next = randomGenerator.nextInt(13);	
							else next = randomGenerator.nextInt(7);	
	
	
	switch (current)
	{
	case 0:
		copy_to_current_ship(typemodel0);
		break;
	case 1:
		copy_to_current_ship(typemodel1);
		break;
	case 2:
		copy_to_current_ship(typemodel2);
		break;
	case 3:
		copy_to_current_ship(typemodel3);
		break;
	case 4:
		copy_to_current_ship(typemodel4);
		break;
	case 5:
		copy_to_current_ship(typemodel5);
		break;
	case 6:
		copy_to_current_ship(typemodel6);
		break;
	case 7:
		copy_to_current_ship(typemodel7);
		break;
	case 8:
		copy_to_current_ship(typemodel8);
		break;
	case 9:
		copy_to_current_ship(typemodel9);
		break;
	case 10:
		copy_to_current_ship(typemodel10);
		break;
	case 11:
		copy_to_current_ship(typemodel11);
		break;
	case 12:
		copy_to_current_ship(typemodel12);
		break;
	case 13:
		copy_to_current_ship(typemodel13);
		break;
	}
//********************
	switch (next)
	{
	case 0:
		copy_to_next_ship(typemodel0);
		break;
	case 1:
		copy_to_next_ship(typemodel1);
		break;
	case 2:
		copy_to_next_ship(typemodel2);
		break;
	case 3:
		copy_to_next_ship(typemodel3);
		break;
	case 4:
		copy_to_next_ship(typemodel4);
		break;
	case 5:
		copy_to_next_ship(typemodel5);
		break;
	case 6:
		copy_to_next_ship(typemodel6);
		break;
	case 7:
		copy_to_next_ship(typemodel7);
		break;
	case 8:
		copy_to_next_ship(typemodel8);
		break;
	case 9:
		copy_to_next_ship(typemodel9);
		break;
	case 10:
		copy_to_next_ship(typemodel10);
		break;
	case 11:
		copy_to_next_ship(typemodel11);
		break;
	case 12:
		copy_to_next_ship(typemodel12);
		break;
	case 13:
		copy_to_next_ship(typemodel13);
		break;
	}	
	
	
}

//************************************************
private void copy_to_current_ship(spiriteModel[][] _typemodel) 
{
	
	
	int r,g,b;
	r=255;g=255;b=255;//Choose random color
	
	
	/*if(cocolor<0)cocolor*=-1;
	
	long coc= System.currentTimeMillis()%10;
	cocolor=(int) coc;*/
	switch (cocolor)
	{
	case 0: r=254;g=127;b=39;
	break;
	case 1: r=254;g=242;b=0;
	break;
	case 2: r=181;g=230;b=29;
	break;
	case 3: r=254;g=201;b=14;
	break;
	case 4: r=0;g=162;b=232;
	break;
	case 5: r=163;g=73;b=164;
	break;
	case 6: r=255;g=174;b=201;
	break;
	case 7: r=254;g=255;b=0;
	break;
	case 8: r=254;g=0;b=0;
	break;
	case 9: r=0;g=245;b=0;
	break;
	case 10: r=255;g=255;b=255;
	break;
	
	}
	
	//r=181;g=230;b=29;
	cocolor = randomGeneratorColor.nextInt(10);
	
	//****************************Fill the model and it's color
	for(int i=0;i<5;i++)
	for(int j=0;j<5;j++)
		{current_typemodel[i][j].filled=_typemodel[i][j].filled;
		current_typemodel[i][j].r=r;
		current_typemodel[i][j].g=g;
		current_typemodel[i][j].b=b;
		current_typemodel[i][j].rect.setColor((float)r/255,(float)g/255,(float)b/255);
		}
	//*********give it an initial position
	centerPosX=0;centerPosY=4;
	
}
//************************************
private void copy_to_next_ship(spiriteModel[][] _typemodel) 
{
	
	
	int r,g,b;
	r=255;g=255;b=255;//Choose random color
	
	
	/*if(cocolor<0)cocolor*=-1;
	
	long coc= System.currentTimeMillis()%10;
	cocolor=(int) coc;*/
	switch (cocolor)
	{
	case 0: r=254;g=127;b=39;
	break;
	case 1: r=254;g=242;b=0;
	break;
	case 2: r=181;g=230;b=29;
	break;
	case 3: r=254;g=201;b=14;
	break;
	case 4: r=0;g=162;b=232;
	break;
	case 5: r=163;g=73;b=164;
	break;
	case 6: r=255;g=174;b=201;
	break;
	case 7: r=254;g=255;b=0;
	break;
	case 8: r=254;g=0;b=0;
	break;
	case 9: r=0;g=245;b=0;
	break;
	case 10: r=255;g=255;b=255;
	break;
	
	}
	
	//r=181;g=230;b=29;
	
	
	//****************************Fill the model and it's color
	for(int i=0;i<5;i++)
	for(int j=0;j<5;j++)
		{next_typemodel[i][j].filled=_typemodel[i][j].filled;
		next_typemodel[i][j].r=r;
		next_typemodel[i][j].g=g;
		next_typemodel[i][j].b=b;
		next_typemodel[i][j].rect.setColor((float)r/255,(float)g/255,(float)b/255);
		}
	//*********give it an initial position
	
}
//************************************
public void rotate_ship()
{

	
	
	int x1,y2;
	x1=4;y2=4;
	for(int j=4;j>=0;j--)
		for(int i=0;i<5;i++)
		
		{
			temp_current_typemodel[x1][y2].filled=current_typemodel[i][j].filled;
			y2--;
			if(y2<0){x1--;y2=4;}
			
		}
	
boolean ok=true;

for(int i=0;i<5;i++)
	for(int j=0;j<5;j++)
	
	if(temp_current_typemodel[i][j].filled && mymodel[i+this.centerPosX][j+this.centerPosY].filled)	
	{
		ok=false;break;	
	}
	
	
	if(ok==false)return;
	
	for(int i=0;i<5;i++)
		for(int j=0;j<5;j++)
		{
			current_typemodel[i][j].filled=temp_current_typemodel[i][j].filled;
			if(current_typemodel[i][j].filled==true){
				current_typemodel[i][j].r=current_typemodel[2][2].r;
				current_typemodel[i][j].g=current_typemodel[2][2].g;
				current_typemodel[i][j].b=current_typemodel[2][2].b;
current_typemodel[i][j].rect.setColor((float)current_typemodel[i][j].r/255,(float)current_typemodel[i][j].g/255,(float)current_typemodel[i][j].b/255);

												}
			
		}
	
}

public void chape_cant_down()
{
	
	/******************if the position is 0,0 so game over---> init all data**/
	
	if(this.centerPosX==0){
			calculate_is_performed=true;
	 for(int i=1;i<21;i++)
	    	for(int j=1;j<11;j++)
	    		mymodel[i][j].filled=false;
	 
	 paint_scene();   		
	 game_paused=true;
	 score=0;lines=0;
	return;
					}
	/************************/
	
	no_chip=true;calculate_is_performed=true;
	int next_score=100;
for(int i=0;i<5;i++)
	for(int j=0;j<5;j++)
	{if(current_typemodel[i][j].filled==false)continue;
		mymodel[centerPosX+i][centerPosY+j].filled=true;
		mymodel[centerPosX+i][centerPosY+j].r=current_typemodel[i][j].r;
		mymodel[centerPosX+i][centerPosY+j].g=current_typemodel[i][j].g;
		mymodel[centerPosX+i][centerPosY+j].b=current_typemodel[i][j].b;	
		mymodel[centerPosX+i][centerPosY+j].rect.setColor((float)current_typemodel[i][j].r/255,(float)current_typemodel[i][j].g/255,(float)current_typemodel[i][j].b/255);

	}
//if(no_chip==true){calculate_is_performed=false;return;}

boolean ok;
boolean all_checked;
all_checked=true;
while(all_checked)
{ all_checked=false;
for(int i=20;i>0;i--)
	
	{
	ok=true;
	for(int j=1;j<11;j++)
	{
	if(mymodel[i][j].filled==false)	{ok=false;break;}
	}	
	
	if(ok==true)
	{   lines++;
		score+=next_score;
		next_score+=100;
		all_checked=true;
		for(int k=i;k>0;k--)
		{
			for(int kj=1;kj<11;kj++)
			{
				mymodel[k][kj].filled=mymodel[k-1][kj].filled;
				if(mymodel[k][kj].filled==true)
				{
					mymodel[k][kj].r=mymodel[k-1][kj].r;
					mymodel[k][kj].g=mymodel[k-1][kj].g;
					mymodel[k][kj].b=mymodel[k-1][kj].b;
					mymodel[k][kj].rect.setColor((float)mymodel[k][kj].r/255, (float)mymodel[k][kj].g/255, (float)mymodel[k][kj].b/255);
				}
			}
			
		}
		for(int kj=1;kj<11;kj++)
		{
			mymodel[0][kj].filled=false;
		}
		
	}//if ok==true
	
	}//for i
		
	
	
	
	
}//while
this.generate_new_ship();
this.paint_scene();
calculate_is_performed=false;

}

public boolean game_started;
public boolean game_paused;
}//my class









