package com.android.Game.Tuto;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.anddev.andengine.engine.options.EngineOptions;
import org.anddev.andengine.engine.options.EngineOptions.ScreenOrientation;
import org.anddev.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.scene.background.ColorBackground;
import org.anddev.andengine.entity.util.FPSLogger;
import org.anddev.andengine.opengl.font.Font;
import org.anddev.andengine.opengl.texture.TextureOptions;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.anddev.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlasTextureRegionFactory;
import org.anddev.andengine.opengl.texture.region.TextureRegion;
import org.anddev.andengine.ui.activity.BaseGameActivity;

import android.content.Context;
import android.graphics.Camera;
import android.graphics.Color;
import android.graphics.Typeface;
import android.service.wallpaper.WallpaperService.Engine;
import android.view.KeyEvent;
import com.android.Game.Tuto.GameManager;
import android.view.KeyEvent;
import  android.view.InputEvent;
import android.view.MotionEvent;
import android.view.KeyEvent.*;
import org.anddev.andengine.entity.sprite.*;
import org.anddev.andengine.entity.text.ChangeableText;
import org.anddev.andengine.input.touch.TouchEvent;
public class AndroidTutoActivity extends BaseGameActivity {
	// ===========================================================
	// Constants
	// ===========================================================

	private static final int CAMERA_WIDTH = 640;
	private static final int CAMERA_HEIGHT = 480;
	public static boolean switch_color=true;
	public GameManager Game;
	private TextureRegion regionImage;
	
	public  ChangeableText monScore;
	public  ChangeableText myline;
	public  ChangeableText mybestLine;
	public  ChangeableText monBestScore;
	public ChangeableText monTexteoff;
	// ===========================================================
	private BitmapTextureAtlas btnTexture;
	private TextureRegion btn_playRegion;
	private Sprite pauseBtn;
	
	private BitmapTextureAtlas saveTexture;
	private TextureRegion btn_saveRegion;
	private Sprite saveBtn;
	
	private BitmapTextureAtlas loadTexture;
	private TextureRegion btn_loadRegion;
	private Sprite loadBtn;
	
	
	private BitmapTextureAtlas exitTexture;
	private TextureRegion btn_exitRegion;
	private Sprite exitBtn;
	
	
	private BitmapTextureAtlas classicTexture;
	private TextureRegion btn_classicRegion;
	private Sprite classicBtn;
	//***********************************************************
	public int best_score;
	public int best_line;
	
	float lastx,lasty,x,y;
	long time_to_move_left_down_up;
	boolean pressed;
	// ===========================================================
	
	///=============================================================

	private org.anddev.andengine.engine.camera.Camera mCamera;

	// ===========================================================
	// Constructors
	// ===========================================================

	// ===========================================================
	// Getter & Setter
	// ===========================================================

	// ===========================================================
	// Methods for/from SuperClass/Interfaces
	// ===========================================================

	@Override
	public org.anddev.andengine.engine.Engine onLoadEngine() {
		this.mCamera = new org.anddev.andengine.engine.camera.Camera(0, 0, CAMERA_WIDTH, CAMERA_HEIGHT);
		org.anddev.andengine.engine.Engine temp=
		 new org.anddev.andengine.engine.Engine(
				 new EngineOptions(true, ScreenOrientation.LANDSCAPE, 
						 new RatioResolutionPolicy(CAMERA_WIDTH, CAMERA_HEIGHT)
				 , this.mCamera));
		
		return temp;
	}

	@Override
	public void onLoadResources() {
		

		
		
		//**************save btn
		saveTexture= new BitmapTextureAtlas(128,64,TextureOptions.BILINEAR_PREMULTIPLYALPHA);
	   btn_saveRegion= BitmapTextureAtlasTextureRegionFactory.createFromAsset(saveTexture, this, "gfx/save.png",0,0);
	      getEngine().getTextureManager().loadTexture(saveTexture);
		
	      btnTexture= new BitmapTextureAtlas(128,64, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
			btn_playRegion= BitmapTextureAtlasTextureRegionFactory.createFromAsset(btnTexture, this, "gfx/start.png",0 ,0);
			getEngine().getTextureManager().loadTexture(btnTexture);
			
			  exitTexture= new BitmapTextureAtlas(128,64, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
				btn_exitRegion= BitmapTextureAtlasTextureRegionFactory.createFromAsset(exitTexture, this, "gfx/exit.png",0 ,0);
				getEngine().getTextureManager().loadTexture(exitTexture);
				
				 loadTexture= new BitmapTextureAtlas(128,64, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
					btn_loadRegion= BitmapTextureAtlasTextureRegionFactory.createFromAsset(loadTexture, this, "gfx/load.png",0 ,0);
					getEngine().getTextureManager().loadTexture(loadTexture);
					
					classicTexture= new BitmapTextureAtlas(128,64, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
					btn_classicRegion= BitmapTextureAtlasTextureRegionFactory.createFromAsset(classicTexture, this, "gfx/classic.png",0 ,0);
					getEngine().getTextureManager().loadTexture(classicTexture);
	}

	@Override
	public Scene onLoadScene() {
		this.mEngine.registerUpdateHandler(new FPSLogger());

		final Scene scene = new Scene(1);
		if(switch_color==true){switch_color=false;
		scene.setBackground(new ColorBackground(0, 0, 0));
							}
		else {switch_color=true;
		scene.setBackground(new ColorBackground(0, 0, 0));
		} 
		//************load mes image
		final BitmapTextureAtlas textureImage = new BitmapTextureAtlas(512, 128,TextureOptions.BILINEAR);
		regionImage = BitmapTextureAtlasTextureRegionFactory.createFromAsset(textureImage, this, "gfx/me.png", 0, 0);	
			
		this.getEngine().getTextureManager().loadTexture(textureImage);
		final Sprite sprite = new Sprite(300,0, regionImage);
		scene.attachChild(sprite);
		
		
		//********************botton click
		
		pauseBtn= new Sprite(300, 300, this.btn_playRegion){
			@Override
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent, float pTouchAreaLocalX, float pTouchAreaLocalY) {
	   			 if(pSceneTouchEvent.getAction()==MotionEvent.ACTION_UP){
	   				// this.setVisible(false);
	   				if(Game.game_started==false)
	   				{
	   					Game.game_started=true;
	   					Game.game_paused=false;
	   				 Game.generate_new_ship();
	   				 Game.calculate_is_performed=false;
	   				}
	   				
	   				else {
	   					
	   				      if(Game.game_paused==false)
	   				      {
	   				    	Game.game_paused=true;Game.calculate_is_performed=true;  
	   				      }
	   				      else {
	   				    	Game.game_paused=false;Game.calculate_is_performed=false;
	   				      }
	   				
	   				}
	   				
	   				 
	   			 }
	   			
	   			 return true;
       	}};
       	
       	
     
       	//*********************save btn
       	saveBtn= new Sprite(300, 356, this.btn_saveRegion){
			@Override
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent, float pTouchAreaLocalX, float pTouchAreaLocalY) {
	   			 if(pSceneTouchEvent.getAction()==MotionEvent.ACTION_UP){
	   				
	   			 //***********save to file
	   			String FILENAME = "titris_scoring_file.red";
	   			
	   			
	   			int magic=1986;

	   			FileOutputStream fos;
				try {
					if(best_score<Game.score){best_line=Game.lines;best_score=Game.score;}
					
					fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
					fos.write((Integer.toString(magic)+"\n").getBytes());
					fos.write((Integer.toString(best_score)+"\n").getBytes());
					fos.write((Integer.toString(best_line)+"\n").getBytes());
					mybestLine.setText(Integer.toString  (best_line));
					monBestScore.setText(Integer.toString  (best_score));
					
					
					
					fos.write((Integer.toString(Game.score)+"\n").getBytes());
					fos.write((Integer.toString(Game.lines)+"\n").getBytes());
					
					while (Game.calculate_is_performed==true){Thread.sleep(40,0);}
					
					Game.calculate_is_performed=true;
					for(int i=0;i<21;i++)
						for(int j=1;j<11;j++)
							if(Game.mymodel[i][j].filled)
							{
							fos.write((Integer.toString((int)1)+"\n").getBytes());		
							fos.write((Integer.toString(Game.mymodel[i][j].r)+"\n").getBytes());
							fos.write((Integer.toString(Game.mymodel[i][j].g)+"\n").getBytes());	
							fos.write((Integer.toString(Game.mymodel[i][j].b)+"\n").getBytes());		
							}
							else fos.write((Integer.toString((int)0)+"\n").getBytes());	
					
					
					
					
					Game.calculate_is_performed=false;
					
		   			fos.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch (InterruptedException e) {e.printStackTrace();}	
	   			 //**********************
	   			 
	   			 															}
	   			 
	   			 return true;
       	}};
       		scene.attachChild(saveBtn);
       	scene.registerTouchArea(saveBtn);
     //====================================================================================================================  	
       	loadBtn= new Sprite(300, 356, this.btn_loadRegion){
			@Override
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent, float pTouchAreaLocalX, float pTouchAreaLocalY) {
	   			 if(pSceneTouchEvent.getAction()==MotionEvent.ACTION_UP){
	   				
	   				String FILENAME = "titris_scoring_file.red";
	   	   			
	   	   			

	   	   			FileInputStream fos;
	   				try {
	   					fos = openFileInput(FILENAME);
	   					
	   					InputStream in = null;
	   					   
	   					     in = new BufferedInputStream(fos);
	   					    DataInputStream din=new DataInputStream(in);
	   					
	   					    while (Game.calculate_is_performed==true)
	 					{
	 						 try {
	 			                   
	 		                    	Thread.sleep(40,0);
	 		                    	
	 		                       }	
	 		                       catch (InterruptedException e) {e.printStackTrace();}	
	 			 					
	 					}
	   					 Game.calculate_is_performed=true;
	   					 
	   					 int magic=0;
	   					magic=Integer.parseInt(din.readLine());	 
	   				if(magic==1986){
	   				best_score=Integer.parseInt(din.readLine());	   
	   				best_line=Integer.parseInt(din.readLine());
	   					 
	   				Game.score=Integer.parseInt(din.readLine());/**/	     
	   				Game.lines=Integer.parseInt(din.readLine());
				
						int filled,r,g,b;
						
						filled=0;
						for(int i=0;i<21;i++)
							for(int j=1;j<11;j++)
								{
							 filled=Integer.parseInt(din.readLine());
								if(filled==1)
								{   Game.mymodel[i][j].filled=true;
									r=Integer.parseInt(din.readLine());		
									g=Integer.parseInt(din.readLine());
									b=Integer.parseInt(din.readLine());	
								Game.mymodel[i][j].r=r;
								Game.mymodel[i][j].g=g;
								Game.mymodel[i][j].b=b;
								Game.mymodel[i][j].rect.setColor((float)r/255,(float)g/255,(float)b/255);
										
								}
								else {Game.mymodel[i][j].filled=false;	}
	   					 
								}
	   					 
						
	   				}
						 if(Game.game_started==false)
		 	   				{
		 	   					Game.game_started=true;
		 	   					Game.game_paused=false;
		 	   				 Game.generate_new_ship();
		 	   				
		 	   				}   
						 else {Game.game_paused=false;Game.centerPosX=0;Game.centerPosY=4;}
	   					    
						 Game.paint_scene();
						 Game.calculate_is_performed=false;
	   		   			fos.close();
	   				} catch (FileNotFoundException e) {
	   					// TODO Auto-generated catch block
	   					e.printStackTrace();
	   				} catch (IOException e) {
	   					// TODO Auto-generated catch block
	   					e.printStackTrace();
	   				}	
	   				 
	   				 
	   			 }
	   			 
	   			 return true;
       	}};
       		scene.attachChild(loadBtn);
       	scene.registerTouchArea(loadBtn);
     //====================================================================================================================  	
       	exitBtn= new Sprite(300, 412, this.btn_exitRegion){
			@Override
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent, float pTouchAreaLocalX, float pTouchAreaLocalY) {
	   			 if(pSceneTouchEvent.getAction()==MotionEvent.ACTION_UP){
	   				
	   			 //***********save to file
	   			
	   			
	   			
	   			
	   			Game.calculate_is_performed=true;
	   			try {
	   				finish();
				} catch (Throwable e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	   			 														}
	   			 return true;
       	}};
       	//==================================================================================================================
       		scene.attachChild(exitBtn);
       	scene.registerTouchArea(exitBtn);
       	//************
     	classicBtn= new Sprite(300, 412, this.btn_classicRegion){
			@Override
			public boolean onAreaTouched(TouchEvent pSceneTouchEvent, float pTouchAreaLocalX, float pTouchAreaLocalY) {
	   			 if(pSceneTouchEvent.getAction()==MotionEvent.ACTION_UP){
	   				
	   			if(Game.extrat_mode==true){Game.extrat_mode=false;monTexteoff.setText("OFF");  } 
	   			else{ Game.extrat_mode=true;monTexteoff.setText("ON"); }
	   			
				
	   			 														}
	   			 return true;
       	}};
       	//==================================================================================================================
       		scene.attachChild(classicBtn);
       	scene.registerTouchArea(classicBtn);
       	//************
       	//pauseBtn.setScale(2);
       	scene.attachChild(pauseBtn);
       	scene.registerTouchArea(pauseBtn);
       
		//*********************
		
       	pauseBtn.setPosition(300,199);
       	saveBtn.setPosition(300,255);
       	loadBtn.setPosition(300,311);
       	classicBtn.setPosition(300,367);
       	exitBtn.setPosition(300,423);
       			
       	
       	
       	time_to_move_left_down_up=System.currentTimeMillis();	
		return scene;
	}

	@Override
	public void onLoadComplete() {
		
		Game = new GameManager(this.getEngine().getScene());
		//Game.generate_new_ship();
		Game.game_started=false;
		// start the thread ho force the user to down the ship
		 new Thread(new Runnable() {
	            @Override
	            public void run() {
	            	boolean down;
	            	down=true;Game.paint_scene();
				while (true)
				                    	{	
					while (Game.calculate_is_performed==true)
					{
						 try {
			                   
		                    	Thread.sleep(100,0);
		                    	Game.paint_scene();
		                       }	
		                       catch (InterruptedException e) {e.printStackTrace();}	
			 					
					}
					
					 Game.last_down=System.currentTimeMillis();
					 while(System.currentTimeMillis()-Game.last_down<=(1000-((Game.lines/30)*100)))	
	                    	
					 					{
				                    try {
				                    	//i=j/i;
				                    	Thread.sleep(30,0);
				                        }	
				                       catch (InterruptedException e) {e.printStackTrace();}	
					 					}//*****while loop and wait
				                //	down=Game.downShip();
				             if(Game.calculate_is_performed==false)       
				             {	if(!Game.downShip())Game.chape_cant_down();
				             monScore.setText(Integer.toString(Game.score));
				             myline.setText(Integer.toString  (Game.lines));
				             Game.paint_scene();
									Game.last_down=System.currentTimeMillis();	
				             }		
				                    	
				                    	
				                     	}
	            }

				
	        }).start();
		 
		 Font font,font1,font2,font3,font4;
		 final BitmapTextureAtlas fontTexture = new BitmapTextureAtlas(256, 256, TextureOptions.BILINEAR);
		 final BitmapTextureAtlas fontTexture1 = new BitmapTextureAtlas(256, 256, TextureOptions.BILINEAR);
		 final BitmapTextureAtlas fontTexture2 = new BitmapTextureAtlas(256, 256, TextureOptions.BILINEAR);
		 final BitmapTextureAtlas fontTexture3 = new BitmapTextureAtlas(256, 256, TextureOptions.BILINEAR);
		 
		 this.getEngine().getTextureManager().loadTexture(fontTexture);
		 this.getEngine().getTextureManager().loadTexture(fontTexture1);
		 this.getEngine().getTextureManager().loadTexture(fontTexture2);
		 this.getEngine().getTextureManager().loadTexture(fontTexture3);
		 
		 //===================================================================================================
		 font = new Font(fontTexture, Typeface.create(Typeface.DEFAULT, Typeface.BOLD), 24, true, Color.GREEN);
		 this.getEngine().getFontManager().loadFont(font);
		 final ChangeableText monTexteBestscore = new ChangeableText(300,60, font , "Best Score   :");
		 							monBestScore = new ChangeableText(470,60, font , "00000000000");
		 //===================================================================================================							
		 font1 = new Font(fontTexture1, Typeface.create(Typeface.DEFAULT, Typeface.BOLD), 24, true, Color.RED);
		 			this.getEngine().getFontManager().loadFont(font1);							
		 final ChangeableText monTexteBestline = new ChangeableText(300,90, font1 ,  "Best Lines   :");
		 									mybestLine= new ChangeableText(470,90, font1 , "00000000000");
		 //===================================================================================================							
		 font2 = new Font(fontTexture2, Typeface.create(Typeface.DEFAULT, Typeface.BOLD), 24, true, Color.BLUE);
		 		this.getEngine().getFontManager().loadFont(font2);	 
		 		final ChangeableText monTextescore = new ChangeableText(300,120, font2 ,    "Actual Score :");
		 	monScore = new ChangeableText(470,120, font2 , "00000000000");
		 //===================================================================================================							
		font3 = new Font(fontTexture3, Typeface.create(Typeface.DEFAULT, Typeface.BOLD), 24, true, Color.YELLOW);
			 		this.getEngine().getFontManager().loadFont(font3);	 	
		final ChangeableText monTexteline = new ChangeableText(300,150, font3 ,     "Actual Lines  :");
		 							myline= new ChangeableText(470,150, font3 , "00000000000");
		
		final ChangeableText monTexteNext = new ChangeableText(500,200, font1 , "Next :");
		 monTexteoff = new ChangeableText(430,384, font1 , "OFF");
		 //***********************************read from file*****************************
		
		 
			best_score=0;best_line=0;
			String FILENAME = "titris_scoring_file.red";
   			
   			

   			FileInputStream fos;
			try {
				fos = openFileInput(FILENAME);
				
				InputStream in = null;
				   
				     in = new BufferedInputStream(fos);
				    DataInputStream din=new DataInputStream(in);
				    int magic=0;
				    magic=Integer.parseInt(din.readLine());
				   if(magic==1986){
					   best_score =Integer.parseInt(din.readLine());
					   best_line=Integer.parseInt(din.readLine());
				   }
	   			fos.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			mybestLine.setText(Integer.toString  (best_line));
			monBestScore.setText(Integer.toString  (best_score));
		//****************************************************************
			 this.getEngine().getScene().attachChild(monTexteNext);
			
			
		 this.getEngine().getScene().attachChild(monTextescore); 
		 this.getEngine().getScene().attachChild(monTexteline);
		 this.getEngine().getScene().attachChild( monTexteBestline); 
		 this.getEngine().getScene().attachChild(monTexteBestscore); 
		 this.getEngine().getScene().attachChild( monScore); 
		 this.getEngine().getScene().attachChild( myline); 
		 this.getEngine().getScene().attachChild(mybestLine); 
		 this.getEngine().getScene().attachChild( monBestScore);
		 this.getEngine().getScene().attachChild( monTexteoff);
		 
	}
	
	/*************************************************************************************/
	private void treat_line_and_generate_new_chip() {
		// TODO Auto-generated method stub
		
	}
	/****************************************************************************************/
	@Override
	public
	boolean onTouchEvent(MotionEvent myevent)
	{
		
		if(Game.calculate_is_performed==true)return super.onTouchEvent(myevent);
		if( myevent.getActionMasked()  !=MotionEvent.ACTION_MOVE) {
				x=myevent.getX(); y=myevent.getY();					return super.onTouchEvent(myevent);
										}
	   	if(System.currentTimeMillis()-time_to_move_left_down_up<200)return super.onTouchEvent(myevent);	
		//if(myevent.getButtonState())
	   	time_to_move_left_down_up=System.currentTimeMillis();
		int mycase=0;
		
		lastx=myevent.getX();lasty=myevent.getY();
		float defx,defy;
		defx=lastx-x;
		defx*=defx;
		defy=lasty-y;
		defy*=defy;
		if( defx>defy)
		{
		if(lastx-x>0){
			Game.move_to_right_Ship();
					}
		else        {
			Game.move_to_left_Ship();
		            }	
			
		}
	else
	{
	if(lasty-y>0){
		if(!Game.downShip()){Game.chape_cant_down();}
		Game.last_down=System.currentTimeMillis();	
				}
	else {
		
		Game.rotate_ship();
	     }
	}
	/*switch(myevent.getAction())
	{
	
		
	case MotionEvent.EDGE_TOP :
		Game.rotate_ship();
		              break;	              
	case MotionEvent.EDGE_LEFT:
		Game.move_to_left_Ship();
		              break;
	case MotionEvent.EDGE_RIGHT:
		Game.move_to_right_Ship();
		              break;
	
	}*/
		
		x=myevent.getX(); y=myevent.getY();		
	Game.paint_scene();	
		
		
	return super.onTouchEvent(myevent);
	}
	
	
	//=========================================================================================
	@Override
	public
	boolean onKeyDown(int keyCode, KeyEvent event) {
		
         if(Game.calculate_is_performed==true)return super.onKeyDown(keyCode, event);
		//if(Game.no_chip==true) {Game.no_chip=false;Game.generate_new_ship();}
		
         time_to_move_left_down_up=System.currentTimeMillis();
		switch (keyCode)
		{
		case 20:
			if(!Game.downShip()){Game.chape_cant_down();}
			Game.last_down=System.currentTimeMillis();	
			break;
		case 21:
			Game.move_to_left_Ship();
			break;
		case 22:
			Game.move_to_right_Ship();
			break;
		case 19:
			Game.rotate_ship();
			break;
			
		
		}
		
		monScore.setText(Integer.toString  (Game.score));
		myline.setText(Integer.toString  (Game.lines));
		Game.paint_scene();
		
		 
		return super.onKeyDown(keyCode, event);
		//return mHasWindowFocused; 				
	
		
	}
	// ===========================================================
	// Methods
	// ===========================================================

	// ===========================================================
	// Inner and Anonymous Classes
	// ===========================================================
}
