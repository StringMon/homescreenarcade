package com.android.Game.Tuto;
import org.anddev.andengine.entity.primitive.Rectangle;
public class spiriteModel {
	public boolean filled;
//	public int color;
	public int r,g,b;
	public Rectangle rect;

}
